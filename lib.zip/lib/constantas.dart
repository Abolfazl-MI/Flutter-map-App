class Constatnts {
  static const mapUrl =
      'https://api.mapbox.com/styles/v1/abolfazl27/ckzc28iyy001j14p9yq8wvn7a/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiYWJvbGZhemwyNyIsImEiOiJja3piZHI0bWUwZTQxMnFxaTN4dWoybXM1In0.UKB9B-khHgXxiNQU7lnWHg';
  static const tokenMap = 'pk.eyJ1IjoiYWJvbGZhemwyNyIsImEiOiJja3piZHI0bWUwZTQxMnFxaTN4dWoybXM1In0.UKB9B-khHgXxiNQU7lnWHg';
  static const titlesId="mapbox.country-boundaries-v1";
}
